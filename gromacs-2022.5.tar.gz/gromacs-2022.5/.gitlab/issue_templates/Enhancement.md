**Summary**

(Why would this be useful?)

**Use cases**

(How will this enhancement make a difference to users, rather than developers?)

**Impact**

(For whom will this matter? Is it likely to have large impact relative to the amount of work required? If you are a developer, is this something you expect to prioritize higher than the (many) other things that could be done to the code? Will it simplify/remove code, rather than add more code? Avoid adding very general nice-to-have features unless you are planning to work on it yourself in the immediate timeframe.)

**Detailed description**

(Please describe the enhancement in detail. Avoid merely linking to external descriptions; developers are unlikely to find time to read external descriptions if the person proposing the enhancement didn't have time to describe it.) 

/label ~Enhancement
