**Summary**

(Why would this be useful?)

**Use cases**

(Describe how the feature will make a differece - from a user point of view, not just developers.)

**Impact**

(What users would this matter to? Is it likely to have large impact relative to the amount of work required?)

**Detailed description**

(Describe the feature in detail. If this is e.g. a new algorithm you developed, are there a lot of people who have cited the paper, or other implementations available? How does it go  beyond the current state of the code?)

**Requirements**

(Is there other stuff needed?)

**Links/references/implementations**

(Having a link to a paper can be a nice addition to a detailed description, but it's unlikely developers will have time to e.g. go and read a paper if you didn't have time to describe the feature in detail here. Would you be willing to write the implementation?)

/label ~Feature

