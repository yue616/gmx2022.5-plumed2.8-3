.. _downloads:

Downloads
=========

|GMX_MANUAL_DOI_STRING|

|GMX_SOURCE_DOI_STRING|

Source code
-----------
* |gmx-source-package-ftp|
* |gmx-source-package-http|
* (md5sum |SOURCE_MD5SUM|)

Other source code versions may be found at the
`web site <https://manual.gromacs.org/>`_.

Regression tests
----------------
* |gmx-regressiontests-package|
* (md5sum |REGRESSIONTEST_MD5SUM|)
